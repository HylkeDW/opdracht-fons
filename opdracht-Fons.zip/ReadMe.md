# Opdracht nabouwen 
In deze opdracht is het volgende voorbeeld nagebouwd die moest voldoen aan de volgende eisen:
- Product overzicht wordt weergegeven zoals de voorbeeld afbeelding

## Bonuspunten voor de volgende onderdelen:
- vanilla javascript hanteert.
*Gelukt, gebruik gemaakt van de functies die in javascript vanilla zitten.*
- gebruik maakt van moderne css technieken zoals flexbox / css grid. 
*Flexbox gebruikt om het product overzicht weer te geven*
- GEEN gebruik maakt van bestaande CSS frameworks zoals Bootstrap.
*Een paar regeles eigen CSS volstaat om het voorbeeld na te bouwen*
- de producten pagina responsive hebt gemaakt.
*Gedaan*
- aandacht hebt besteed aan details (denk hierbij aan een hover / animeren van de producten on load).
*Hoveranimatie toegepast, on load van de producten niet nodig omdat het bestandsformaat extreem klein is zou de loading animatie maar heel kort te zien zijn.*
- code begrijpbaar is voor derden (documentatie, benamingen, structuur).
*Comments toegevoegd in de Javascript*

## Note
Product werkt alleen via een server i.v.m. CORS policy van de meeste brouwers.
bekijk het eindproduct hier: [eindproduct](https://www.hylkedw.nl/happy-online)